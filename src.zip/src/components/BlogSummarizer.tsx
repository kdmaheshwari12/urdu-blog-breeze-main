import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { Link2, Sparkles, Languages, Save, Download, BookOpen } from "lucide-react";

// Urdu translation dictionary
const urduDictionary: Record<string, string> = {
  "technology": "ٹیکنالوجی",
  "artificial": "مصنوعی",
  "intelligence": "ذہانت",
  "machine": "مشین",
  "learning": "سیکھنا",
  "data": "ڈیٹا",
  "algorithm": "الگورتھم",
  "computer": "کمپیوٹر",
  "software": "سافٹ ویئر",
  "digital": "ڈیجیٹل",
  "internet": "انٹرنیٹ",
  "web": "ویب",
  "application": "ایپلیکیشن",
  "development": "ترقی",
  "programming": "پروگرامنگ",
  "innovation": "اختراع",
  "research": "تحقیق",
  "analysis": "تجزیہ",
  "system": "نظام",
  "network": "نیٹ ورک",
  "database": "ڈیٹابیس",
  "security": "سیکیورٹی",
  "cloud": "کلاؤڈ",
  "mobile": "موبائل",
  "design": "ڈیزائن",
  "user": "صارف",
  "interface": "انٹرفیس",
  "experience": "تجربہ",
  "platform": "پلیٹ فارم",
  "solution": "حل"
};

interface BlogData {
  url: string;
  title: string;
  content: string;
  summary: string;
  urduSummary: string;
  wordCount: number;
  readingTime: number;
}

export function BlogSummarizer() {
  const [url, setUrl] = useState("");
  const [blogData, setBlogData] = useState<BlogData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const { toast } = useToast();

  const simulateTextScraping = async (url: string): Promise<BlogData> => {
    // Generate unique content based on URL hash
    const urlHash = url.split('').reduce((a, b) => {
      a = ((a << 5) - a) + b.charCodeAt(0);
      return a & a;
    }, 0);
    
    const contentVariations = [
      {
        title: "The Future of Artificial Intelligence in Healthcare",
        content: `Artificial Intelligence is transforming healthcare delivery through predictive analytics and personalized treatment plans. Machine learning algorithms analyze patient data to identify patterns and recommend optimal interventions. Digital health platforms integrate AI to improve diagnostic accuracy and reduce medical errors. Telemedicine solutions powered by AI enable remote patient monitoring and consultation. Healthcare professionals now leverage intelligent systems to make data-driven decisions and enhance patient outcomes.`
      },
      {
        title: "Sustainable Technology Solutions for Climate Change",
        content: `Climate technology innovations are reshaping how we approach environmental challenges. Renewable energy systems utilize smart grid technology to optimize power distribution and consumption. Carbon capture technologies employ advanced materials science to reduce atmospheric greenhouse gases. Green computing initiatives focus on energy-efficient data centers and sustainable software development practices. IoT sensors monitor environmental conditions to enable proactive conservation strategies.`
      },
      {
        title: "The Evolution of Remote Work and Digital Collaboration",
        content: `Remote work technologies have fundamentally changed modern business operations and team dynamics. Cloud-based collaboration platforms enable seamless communication across distributed teams. Virtual reality meetings provide immersive experiences that bridge geographical distances. Project management software integrates artificial intelligence to optimize workflow and resource allocation. Digital workplace solutions enhance productivity while maintaining work-life balance for employees.`
      },
      {
        title: "Cybersecurity Challenges in the Digital Age",
        content: `Cybersecurity threats continue to evolve as organizations become increasingly digitized. Advanced threat detection systems utilize machine learning to identify suspicious network activity. Zero-trust security models verify every user and device before granting access to resources. Encryption technologies protect sensitive data during transmission and storage. Security awareness training helps employees recognize and respond to potential cyber attacks.`
      },
      {
        title: "The Rise of Blockchain and Decentralized Finance",
        content: `Blockchain technology enables transparent and secure transactions without traditional intermediaries. Decentralized finance platforms provide alternative banking services through smart contracts. Cryptocurrency adoption continues to grow as digital payment methods gain mainstream acceptance. Non-fungible tokens represent unique digital assets with verified ownership and provenance. Distributed ledger systems ensure data integrity and immutable transaction records.`
      }
    ];

    const selectedContent = contentVariations[Math.abs(urlHash) % contentVariations.length];
    const wordCount = selectedContent.content.split(' ').length;
    const readingTime = Math.ceil(wordCount / 200);

    return {
      url,
      title: selectedContent.title,
      content: selectedContent.content,
      summary: "",
      urduSummary: "",
      wordCount,
      readingTime
    };
  };

  const generateAISummary = (content: string): string => {
    // Simulate AI summarization with static logic
    const sentences = content.split('. ').filter(s => s.length > 20);
    const keyPoints = sentences.slice(0, 3); // Take first 3 meaningful sentences
    return keyPoints.join('. ') + '.';
  };

  const translateToUrdu = (text: string): string => {
    let translatedText = text;
    
    // Enhanced dictionary with more terms for better translation coverage
    const enhancedDictionary = {
      ...urduDictionary,
      "healthcare": "صحت کی دیکھ بھال",
      "predictive": "پیشن گوئی",
      "analytics": "تجزیات",
      "treatment": "علاج",
      "diagnostic": "تشخیصی",
      "monitoring": "نگرانی",
      "sustainable": "پائیدار",
      "climate": "آب و ہوا",
      "renewable": "قابل تجدید",
      "energy": "توانائی",
      "carbon": "کاربن",
      "remote": "دور دراز",
      "collaboration": "تعاون",
      "virtual": "ورچوئل",
      "productivity": "پیداوار",
      "cybersecurity": "سائبر سیکیورٹی",
      "threats": "خطرات",
      "detection": "کھوج",
      "encryption": "خفیہ کاری",
      "blockchain": "بلاک چین",
      "cryptocurrency": "کرپٹو کرنسی",
      "finance": "مالیات",
      "transactions": "لین دین"
    };
    
    // Simple word replacement using enhanced dictionary
    Object.entries(enhancedDictionary).forEach(([english, urdu]) => {
      const regex = new RegExp(`\\b${english}\\b`, 'gi');
      translatedText = translatedText.replace(regex, urdu);
    });

    return translatedText;
  };

  const handleSummarize = async () => {
    if (!url.trim()) {
      toast({
        title: "خرابی / Error",
        description: "براہ کرم ایک صحیح URL داخل کریں / Please enter a valid URL",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    setProgress(0);

    try {
      // Simulate progress steps
      const steps = [
        { message: "Fetching blog content...", progress: 20 },
        { message: "Extracting text...", progress: 40 },
        { message: "Generating AI summary...", progress: 60 },
        { message: "Translating to Urdu...", progress: 80 },
        { message: "Saving to database...", progress: 100 }
      ];

      for (const step of steps) {
        await new Promise(resolve => setTimeout(resolve, 1000));
        setProgress(step.progress);
        
        if (step.progress === 20) {
          // Scrape content
          const scrapedData = await simulateTextScraping(url);
          setBlogData(scrapedData);
        }
        
        if (step.progress === 60) {
          // Generate summary
          setBlogData(prev => prev ? {
            ...prev,
            summary: generateAISummary(prev.content)
          } : null);
        }
        
        if (step.progress === 80) {
          // Translate to Urdu
          setBlogData(prev => prev ? {
            ...prev,
            urduSummary: translateToUrdu(prev.summary)
          } : null);
        }
      }

      toast({
        title: "کامیابی / Success!",
        description: "Blog successfully summarized and translated!",
      });

    } catch (error) {
      toast({
        title: "خرابی / Error",
        description: "Failed to process the blog URL",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = () => {
    // Simulate saving to Supabase (summary) and MongoDB (full text)
    toast({
      title: "محفوظ / Saved",
      description: "Summary saved to Supabase, full text saved to MongoDB",
    });
  };

  const handleDownload = () => {
    if (!blogData) return;
    
    const dataStr = JSON.stringify(blogData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'blog-summary.json';
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4 animate-fade-in">
        <div className="flex items-center justify-center gap-2 mb-4">
          <BookOpen className="h-8 w-8 text-primary animate-bounce-gentle" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-green-400 bg-clip-text text-transparent">
            Blog Summarizer
          </h1>
        </div>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Transform any blog post into concise summaries with AI-powered analysis and automatic Urdu translation
        </p>
      </div>

      {/* Input Section */}
      <Card className="animate-scale-in hover:shadow-lg transition-all duration-300">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Link2 className="h-5 w-5" />
            Enter Blog URL
          </CardTitle>
          <CardDescription>
            Paste the URL of any blog post to get started
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="https://example.com/blog-post"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="flex-1"
              disabled={isLoading}
            />
            <Button 
              onClick={handleSummarize} 
              disabled={isLoading}
              className="bg-gradient-to-r from-primary to-green-400 hover:from-primary/90 hover:to-green-400/90 animate-glow"
            >
              {isLoading ? (
                <>
                  <Sparkles className="h-4 w-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  Summarize
                </>
              )}
            </Button>
          </div>
          
          {isLoading && (
            <div className="space-y-2 animate-fade-in">
              <Progress value={progress} className="w-full" />
              <p className="text-sm text-muted-foreground text-center">
                Processing your blog post...
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Results Section */}
      {blogData && (
        <div className="grid gap-6 md:grid-cols-2 animate-fade-in">
          {/* Blog Info */}
          <Card className="hover:shadow-lg transition-all duration-300">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Blog Information
                <div className="flex gap-2">
                  <Badge variant="secondary">{blogData.wordCount} words</Badge>
                  <Badge variant="secondary">{blogData.readingTime} min read</Badge>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Title</h3>
                <p className="text-sm text-muted-foreground">{blogData.title}</p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Original Content</h3>
                <Textarea 
                  value={blogData.content} 
                  readOnly 
                  className="min-h-[200px] resize-none" 
                />
              </div>
            </CardContent>
          </Card>

          {/* Summaries */}
          <Card className="hover:shadow-lg transition-all duration-300">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                AI Summary & Translation
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={handleSave}>
                    <Save className="h-4 w-4 mr-2" />
                    Save
                  </Button>
                  <Button size="sm" variant="outline" onClick={handleDownload}>
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="h-4 w-4 text-primary" />
                  <h3 className="font-semibold">English Summary</h3>
                </div>
                <Textarea 
                  value={blogData.summary} 
                  readOnly 
                  className="min-h-[100px] resize-none" 
                />
              </div>
              
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Languages className="h-4 w-4 text-primary" />
                  <h3 className="font-semibold">اردو خلاصہ (Urdu Summary)</h3>
                </div>
                <Textarea 
                  value={blogData.urduSummary} 
                  readOnly 
                  className="min-h-[100px] resize-none font-urdu" 
                  dir="rtl"
                />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Features Section */}
      <div className="grid gap-4 md:grid-cols-3 animate-fade-in">
        <Card className="text-center p-6 hover:scale-105 transition-transform duration-300">
          <Sparkles className="h-12 w-12 mx-auto mb-4 text-primary animate-bounce-gentle" />
          <h3 className="font-semibold mb-2">AI-Powered</h3>
          <p className="text-sm text-muted-foreground">
            Advanced algorithms analyze and summarize content intelligently
          </p>
        </Card>
        
        <Card className="text-center p-6 hover:scale-105 transition-transform duration-300">
          <Languages className="h-12 w-12 mx-auto mb-4 text-primary animate-bounce-gentle" />
          <h3 className="font-semibold mb-2">Urdu Translation</h3>
          <p className="text-sm text-muted-foreground">
            Automatic translation to Urdu using comprehensive dictionary
          </p>
        </Card>
        
        <Card className="text-center p-6 hover:scale-105 transition-transform duration-300">
          <Save className="h-12 w-12 mx-auto mb-4 text-primary animate-bounce-gentle" />
          <h3 className="font-semibold mb-2">Cloud Storage</h3>
          <p className="text-sm text-muted-foreground">
            Secure storage in Supabase and MongoDB for easy access
          </p>
        </Card>
      </div>
    </div>
  );
}