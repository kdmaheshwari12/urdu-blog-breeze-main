import { Button } from "@/components/ui/button";
import { ArrowDown, BookOpen, Sparkles, Globe } from "lucide-react";

interface HeroSectionProps {
  onGetStarted: () => void;
}

export function HeroSection({ onGetStarted }: HeroSectionProps) {
  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-primary/10" />
      
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-primary/5 rounded-full animate-bounce-gentle" />
        <div className="absolute top-3/4 right-1/4 w-48 h-48 bg-green-400/5 rounded-full animate-bounce-gentle" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-3/4 w-32 h-32 bg-primary/10 rounded-full animate-bounce-gentle" style={{ animationDelay: '2s' }} />
      </div>

      <div className="container mx-auto px-4 text-center relative z-10">
        <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
          {/* Logo/Icon */}
          <div className="flex items-center justify-center gap-3 mb-8">
            <div className="relative">
              <BookOpen className="h-16 w-16 text-primary animate-bounce-gentle" />
              <Sparkles className="h-6 w-6 text-green-400 absolute -top-2 -right-2 animate-bounce-gentle" style={{ animationDelay: '0.5s' }} />
            </div>
          </div>

          {/* Main heading */}
          <h1 className="text-5xl md:text-7xl font-bold leading-tight">
            <span className="bg-gradient-to-r from-primary via-green-400 to-primary bg-clip-text text-transparent animate-glow">
              Blog Summarizer
            </span>
            <br />
            <span className="text-foreground">Made Simple</span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Transform lengthy blog posts into concise, actionable summaries with 
            <span className="text-primary font-semibold"> AI-powered analysis</span> and 
            <span className="text-green-400 font-semibold"> automatic Urdu translation</span>
          </p>

          {/* Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-12">
            <div className="flex items-center justify-center gap-3 p-4 rounded-lg bg-card/50 backdrop-blur-sm border hover:scale-105 transition-transform duration-300">
              <Sparkles className="h-6 w-6 text-primary" />
              <span className="font-medium">AI-Powered Summaries</span>
            </div>
            <div className="flex items-center justify-center gap-3 p-4 rounded-lg bg-card/50 backdrop-blur-sm border hover:scale-105 transition-transform duration-300">
              <Globe className="h-6 w-6 text-green-400" />
              <span className="font-medium">Urdu Translation</span>
            </div>
            <div className="flex items-center justify-center gap-3 p-4 rounded-lg bg-card/50 backdrop-blur-sm border hover:scale-105 transition-transform duration-300">
              <BookOpen className="h-6 w-6 text-primary" />
              <span className="font-medium">Cloud Storage</span>
            </div>
          </div>

          {/* CTA Button */}
          <div className="space-y-4">
            <Button 
              size="lg" 
              onClick={onGetStarted}
              className="bg-gradient-to-r from-primary to-green-400 hover:from-primary/90 hover:to-green-400/90 text-lg px-8 py-6 rounded-full animate-glow hover:scale-105 transition-all duration-300"
            >
              <Sparkles className="h-5 w-5 mr-2" />
              Get Started Now
            </Button>
            <p className="text-sm text-muted-foreground">
              No signup required • Free to use • Instant results
            </p>
          </div>

          {/* Scroll indicator */}
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
            <ArrowDown className="h-6 w-6 text-muted-foreground" />
          </div>
        </div>
      </div>
    </section>
  );
}