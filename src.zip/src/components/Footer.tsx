import { BookOpen, Github, Heart } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t bg-card/50 backdrop-blur-sm">
      <div className="container mx-auto px-4 py-8">
        <div className="grid gap-8 md:grid-cols-3">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <BookOpen className="h-6 w-6 text-primary" />
              <span className="font-bold text-lg">Blog Summarizer</span>
            </div>
            <p className="text-sm text-muted-foreground">
              AI-powered blog summarization with automatic Urdu translation. 
              Making content accessible to everyone.
            </p>
          </div>

          {/* Features */}
          <div className="space-y-4">
            <h3 className="font-semibold">Features</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>✨ AI-Powered Summaries</li>
              <li>🌐 Urdu Translation</li>
              <li>☁️ Cloud Storage</li>
              <li>📱 Mobile Responsive</li>
              <li>🔒 Secure & Private</li>
            </ul>
          </div>

          {/* Tech Stack */}
          <div className="space-y-4">
            <h3 className="font-semibold">Built With</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>⚛️ React + TypeScript</li>
              <li>🎨 ShadCN UI</li>
              <li>🏗️ Supabase</li>
              <li>🍃 MongoDB</li>
              <li>🚀 Vercel</li>
            </ul>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground flex items-center gap-1">
            Made with <Heart className="h-4 w-4 text-red-500 animate-bounce-gentle" /> for Assignment 2
          </p>
          
          <div className="flex items-center gap-4">
            <a 
              href="#" 
              className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200 flex items-center gap-1"
            >
              <Github className="h-4 w-4" />
              Source Code
            </a>
            <span className="text-sm text-muted-foreground">
              © 2024 Blog Summarizer
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}