import { useState, useRef } from "react";
import { HeroSection } from "@/components/HeroSection";
import { BlogSummarizer } from "@/components/BlogSummarizer";
import { Footer } from "@/components/Footer";

const Index = () => {
  const [showSummarizer, setShowSummarizer] = useState(false);
  const summarizerRef = useRef<HTMLDivElement>(null);

  const handleGetStarted = () => {
    setShowSummarizer(true);
    // Smooth scroll to summarizer section
    setTimeout(() => {
      summarizerRef.current?.scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
      });
    }, 100);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <HeroSection onGetStarted={handleGetStarted} />

      {/* Blog Summarizer Section */}
      {showSummarizer && (
        <section 
          ref={summarizerRef}
          className="min-h-screen py-16 animate-fade-in"
        >
          <BlogSummarizer />
        </section>
      )}

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default Index;
